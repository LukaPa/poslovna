package projekat.form.actions;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;


public class NextFormItemAction extends AbstractAction {

	private static final long serialVersionUID = 1L;

	
	
	public NextFormItemAction() {
		putValue(SHORT_DESCRIPTION, "Sledeca forma");
		putValue(NAME, "forma");
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
	}
}
